(function () {
  'use strict';

  const PAGE_SOURCE = 'HADER_WEB';
  const EXTENSION_SOURCE = 'HADER_EXTENSION';
  const ALLOWED_ORIGINS = new Set([
    'https://haderedu.com',
    'https://www.haderedu.com',
    'http://localhost:3000',
    'http://localhost:3001',
    'http://127.0.0.1:3000'
  ]);

  function isAllowedOrigin(origin) {
    return ALLOWED_ORIGINS.has(origin)
      || /^https:\/\/([a-z0-9-]+\.)?moeen\.app$/i.test(origin);
  }

  function post(type, payload) {
    window.postMessage({ source: EXTENSION_SOURCE, type, ...(payload || {}) }, window.location.origin);
  }

  function replyFor(type) {
    if (type === 'HADER_GET_SCHEDULE') return 'HADER_SCHEDULE_RESULT';
    if (type === 'HADER_GET_ALL_WEEKS') return 'HADER_ALL_WEEKS_ACCEPTED';
    if (type === 'HADER_PREPARE_LESSONS') return 'HADER_PREPARATION_ACCEPTED';
    if (type === 'HADER_SYNC_AUTH') return 'HADER_AUTH_SYNCED';
    return 'HADER_BRIDGE_RESULT';
  }

  window.addEventListener('message', (event) => {
    if (event.source !== window || !isAllowedOrigin(event.origin)) return;
    const data = event.data;
    if (!data || data.source !== PAGE_SOURCE) return;
    if (!['HADER_BRIDGE_PING', 'HADER_GET_SCHEDULE', 'HADER_GET_ALL_WEEKS', 'HADER_PREPARE_LESSONS', 'HADER_SYNC_AUTH'].includes(data.type)) return;

    // After the extension is reloaded or updated, this script stays on the page
    // but can no longer reach the extension: chrome.runtime.id goes away and
    // sendMessage throws "Extension context invalidated". Answer the page so it
    // is not left waiting, and tell the teacher how to recover.
    const replyContextLost = () => post(replyFor(data.type), {
      requestId: data.requestId,
      success: false,
      code: 'extension_reloaded',
      error: 'تم تحديث إضافة حضر. حدّث هذه الصفحة ثم أعد المحاولة.'
    });
    if (!chrome.runtime?.id) { replyContextLost(); return; }

    try {
      chrome.runtime.sendMessage({
        action: data.type,
        requestId: data.requestId,
        operationId: data.operationId,
        ticket: data.ticket,
        harvestId: data.harvestId,
        maxWeeks: data.maxWeeks,
        weeksBefore: data.weeksBefore,
        weeksAfter: data.weeksAfter,
        token: data.token,
        previousToken: data.previousToken
      }, (response) => {
        const error = chrome.runtime.lastError;
        post(replyFor(data.type), {
          requestId: data.requestId,
          ...(response || {}),
          ...(error ? { success: false, error: error.message } : {})
        });
      });
    } catch (_) {
      replyContextLost();
    }
  });

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.action === 'HADER_BRIDGE_CONTENT_PING') {
      sendResponse({ success: true, bridgeVersion: '2' });
      return true;
    }
    if (!message || ![
      'HADER_PREPARATION_PROGRESS',
      'HADER_PREPARATION_DONE',
      'HADER_WEEK_HARVESTED',
      'HADER_ALL_WEEKS_DONE'
    ].includes(message.type)) return;
    post(message.type, message.payload || {});
  });

  post('HADER_EXTENSION_READY', { success: true, version: '2' });
})();
